export const environment = {
    production : false,
    firebase : {
        apiKey: "AIzaSyAF5pR1CAvB9iJA7dDTFmE3Knm_idGqnrs",
        authDomain: "tweetx-16a35.firebaseapp.com",
        projectId: "tweetx-16a35",
        storageBucket: "tweetx-16a35.appspot.com",
        messagingSenderId: "455375672935",
        appId: "1:455375672935:web:1795774e241e202328a6c2",
        measurementId: "G-F0286LQJCV"
      }
}