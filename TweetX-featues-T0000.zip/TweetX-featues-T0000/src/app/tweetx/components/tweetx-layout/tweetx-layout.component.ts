import { Component } from '@angular/core';

@Component({
  selector: 'app-tweetx-layout',
  templateUrl: './tweetx-layout.component.html',
  styleUrls: ['./tweetx-layout.component.css'],
})
export class TweetxLayoutComponent {}
